import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModalConfig, NgbModal,ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { FormDataService } from '../data/formData.service';
import { WorkDetails } from '../data/formdata.model';

@Component({
  selector: 'app-work',
  templateUrl: './work.component.html',
  styleUrls: ['./work.component.css']
})
export class WorkComponent implements OnInit {
  closeResult: string;
  workDetails: WorkDetails;
  from: any;
  constructor(private router: Router, private formDataService: FormDataService, config: NgbModalConfig, private modalService: NgbModal) {
    config.backdrop = 'static';
    config.keyboard = false;
  }

  ngOnInit() {
    this.workDetails = this.formDataService.getWorkDetails();
  }
  //  open(content) {
  //     this.modalService.open(content);
  //   }
  open(content) {
    this.modalService.open(content, { size: 'lg' });
    // this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
    //   this.closeResult = `Closed with: ${result}`;
    // }, (reason) => {
    //   this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    // });
  }
openLg(content) {
    this.modalService.open(content, { size: 'lg' });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  save(form: any): boolean {
    if (!form.valid) {
      return false;
    }
    this.formDataService.setWorkDetails(this.workDetails)
    return true;
  }
  forNext(from: any) {
    if (this.save(from)) {
      this.router.navigate(['/']);
    }
  }

}
