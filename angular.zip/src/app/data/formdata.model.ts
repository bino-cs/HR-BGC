export class FormData {
    firstName: string = '';
    lastName: string = '';
    email: string = '';
    work: string = '';
    street: string = '';
    city: string = '';
    state: string = '';
    zip: string = '';
    dob: string = '';
    contactNumber: string = '';
    startDate: string = '';
    endDate: string = '';
    institutionName: string = '';
    universityName: string = '';
    certificatePath: string = '';
    workingStartDate: string = '';
    workingEndDate: string = '';
    isStillWorking:boolean=false;
    companyName: string = '';
    releavingLetter: string = '';
    experianceLetter: string = '';    
    clear() {
        this.firstName = '';
        this.lastName = '';
        this.email = '';
        this.work = '';
        this.street = '';
        this.city = '';
        this.state = '';
        this.zip = '';
        this.dob = '';
        this.contactNumber = '';
    }
}

export class Personal {
    firstName: string = '';
    lastName: string = '';
    email: string = '';
}

export class Address {
    street: string = '';
    city: string = '';
    state: string = '';
    zip: string = '';
}

export class EducationDetails {
    startDate: string = '';
    endDate: string = '';
    institutionName: string = '';
    universityName: string = '';
    certificatePath: string = '';    
    
}

export class WorkDetails{
    workingStartDate: string = '';
    workingEndDate: string = '';
    isStillWorking:boolean=false;
    companyName: string = '';
    releavingLetter: string = '';
    experianceLetter: string = '';    
}