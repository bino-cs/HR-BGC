import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { UiSwitchModule } from 'ngx-toggle-switch';
// import { NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal'

import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';

import { FormDataService } from '../data/formData.service';
import { WorkDetails, Personal } from '../data/formdata.model';
import { WorkListComponent } from '../work/worklist/worklist.component';
import { WorkService } from '../data/work.servise';

@Component({
  selector: 'app-work',
  templateUrl: './work.component.html',
  styleUrls: ['./work.component.css']
  // providers: [NgbModalConfig, NgbModal]
})
export class WorkComponent implements OnInit {
  closeResult: string;
  workDetails: WorkDetails[];
  workDetail: WorkDetails;
  personal: Personal;
  from: any;
  public modalRef: BsModalRef;  
  constructor(private formBuilder: FormBuilder, private modalService: BsModalService, private router: Router, private formDataService: FormDataService, private _workService: WorkService) { }

  ngOnInit(): void {
    this._workService.getWorkDetails().subscribe(
      data => this.workDetails = data,
      err => console.log(err)
    );
    
  }

  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template); // {3}
  }



  public cancelWorkDetails() {
    // workDetails=
    // this.formDataService.setWorkDetails()
  }



  // open(content) {
  //   this.modalService.open(content).result.then((result) => {           
  //           this.closeResult = `Closed with: ${result}`

  //   }, (reason) => {
  //     this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  //   });
  // }

  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return  `with: ${reason}`;
  //   }
  // }

  save(form: any): boolean {
    if (!form.valid) {
      return false;
    }
    // this.formDataService.setWorkDetails(this.workDetail)
    return true;
  }
  forNext(from: any) {
    if (this.save(from)) {
      this.router.navigate(['/']);
    }
  }

}
