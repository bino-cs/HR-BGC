import { Component, OnInit } from '@angular/core';
import { UiSwitchModule } from 'ngx-toggle-switch';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validator } from '@angular/forms';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal'

import { WorkDetails, Personal } from '../../data/formdata.model';
import { FormDataService } from '../../data/formData.service';
import { WorkService } from '../../data/work.servise';
@Component({
    selector: 'bgc-worklist',
    templateUrl: './worklist.component.html',
    styleUrls: ['./worklist.component.css']
})

export class WorkListComponent implements OnInit {
    workDetails: WorkDetails[];
    workDetail: WorkDetails;
    addWorkDetails: FormGroup;
    public modalRef: BsModalRef;
    display='none'
    constructor(private formBuilder: FormBuilder,private modalService:BsModalService, private router: Router, private formDataService: FormDataService, private _workService: WorkService) { }
    ngOnInit(): void {
        // this.workDetail = this.formDataService.getWorkDetails();

        this.addWorkDetails = this.formBuilder.group({
            companyName: [''],
            isStillWorking: [false],
            workingStartDate: [''],
            workingEndDate: [''],
            companyAddress: [''],
            companyCity: [''],
            stateProvinceRegion: [''],
            postalcodeZip: [''],
            companyCountry: [''],
            companyphoneNumber: [''],
            companyEmailId: [''],
            refNumber: [''],
            releavingLetter: [''],
            experianceLetter: [''],
            workBGCStatus: ['']
        });
    }
    public saveWorksDetail(): void {
        console.log(this.addWorkDetails.value);
        this._workService.saveWorkDetails(this.addWorkDetails.value).subscribe(
            data => {   
              this.closeModal();
                this.router.navigate(['/work']);

            }
            , err => { console.log(err) }
        );
    }
    public closeModal(){
        this.display='none';
    }  

}


