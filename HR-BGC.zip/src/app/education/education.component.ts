import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal'

import { FormDataService } from '../data/formData.service';
import { EducationService } from '../data/education.service'
import { EducationDetails } from '../data/formdata.model';

@Component({
    selector: 'app-education',
    templateUrl: './education.component.html',
    styleUrls: ['./education.component.css']
})

export class EducationComponent implements OnInit {
    title = 'Education details';
    //  educationDetails:EducationDetails;
    form: any;
    public modalRef: BsModalRef;
    educationDetails: EducationDetails[] = [];
    data: any;
    educationDetail: EducationDetails;
    AddEducation: FormGroup;
    showMsg: boolean = false;
    constructor(private formBuilder: FormBuilder, private modalService: BsModalService, private router: Router, private _educationService: EducationService, formDataService: FormDataService) {

    }

    //   ngOnInit() {
    //       this.educationDetails=this.formDataService.getEducation();
    //   }
    ngOnInit(): void {
        this._educationService.getAllEducation().subscribe(
            data => this.educationDetails = data,
            err => console.log(err),
            () => console.log(this.educationDetails)

        );

        this.AddEducation = this.formBuilder.group({
            courseName: [''],
            startDate: [''],
            endDate: [''],
            institutionName: [''],
            universityName: [''],
            certificatePath: [''],
            educationBGCStatus: ['']
        });
    }

    public openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template); // {3}
    }

    save(form: any): boolean {
        if (!form.valid) {
            return false;
        }
        return true;
    }
    saveEducationDetail(): void {
        this._educationService.saveAllEducation(this.AddEducation.value).subscribe(
            data => {
                this.showMsg = true;
                this.modalRef.hide();
                this.ngOnInit();
            }, err => console.log(err)
        );
    }

    goToNext(form: any) {
        this.router.navigate(['/work']);
        // if (this.save(form)) {
        // Navigate to the address page
        // this.router.navigate(['/work']);
        // }
    }

    goToPrevious(form: any) {
        if (this.save(form)) {
            // Navigate to the personal page
            this.router.navigate(['/personal']);
        }
    }

}
