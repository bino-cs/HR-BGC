import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { FormDataService } from '../data/formData.service';
import { EducationDetails } from '../data/formdata.model';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent implements OnInit {
 title='Education details';
 educationDetails:EducationDetails;
 form:any;
  constructor(private router:Router,private formDataService:FormDataService) { }

  ngOnInit() {
      this.educationDetails=this.formDataService.getEducation();
  }

 save(form: any): boolean {
        if (!form.valid) {
            return false;
        }
        this.formDataService.setEducation(this.educationDetails);
        return true;
    }

   goToNext(form: any) {
        this.router.navigate(['/work']);
        if (this.save(form )) {
            // Navigate to the address page
            this.router.navigate(['/work']);
        }
    }

    goToPrevious(form: any) {
        if (this.save(form)) {
            // Navigate to the personal page
            this.router.navigate(['/personal']);
        }
    }
    
}
