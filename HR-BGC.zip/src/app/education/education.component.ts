import { Component, OnInit,TemplateRef } from '@angular/core';
import { Router } from '@angular/router';

import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal'

import { FormDataService } from '../data/formData.service';
import{ EducationService } from '../data/education.service'
import { EducationDetails } from '../data/formdata.model';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent implements OnInit {
 title='Education details';
//  educationDetails:EducationDetails;
 form:any;
 public modalRef: BsModalRef;
 educationDetails : EducationDetails[]=[];
  constructor(private modalService: BsModalService,private router:Router,private _educationService:EducationService,formDataService:FormDataService) { }

//   ngOnInit() {
//       this.educationDetails=this.formDataService.getEducation();
//   }
public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template); // {3}
  }
  
 save(form: any): boolean {
        if (!form.valid) {
            return false;
        }
        // this.formDataService.setEducation(this.educationDetails);
        return true;
    }
saveEducationDetail(){
}
ngOnInit(): void {
        this._educationService.getAllEducation().subscribe(
            data=>this.educationDetails=data,
            err=>console.log(err),
            ()=>console.log("Events Service call completed!")
        );
    }


   goToNext(form: any) {
        this.router.navigate(['/work']);
        if (this.save(form )) {
            // Navigate to the address page
            this.router.navigate(['/work']);
        }
    }

    goToPrevious(form: any) {
        if (this.save(form)) {
            // Navigate to the personal page
            this.router.navigate(['/personal']);
        }
    }
    
}
