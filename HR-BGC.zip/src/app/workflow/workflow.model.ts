// To do
// Need to move from const to enum type
export const STEPS = {
    personal: 'personal',
    educaation:'education',
    work: 'work',
    address: 'address',
    result: 'result'
    
}

