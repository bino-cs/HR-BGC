import { Injectable } from '@angular/core';

import { FormData, Personal, Address, EducationDetails, WorkDetails } from './formData.model';
import { WorkflowService } from '../workflow/workflow.service';
import { STEPS } from '../workflow/workflow.model';

@Injectable()
export class FormDataService {

    private formData: FormData = new FormData();
    private isPersonalFormValid: boolean = false;
    private isWorkFormValid: boolean = false;
    private isAddressFormValid: boolean = false;
    private isEducationDetailsValid: boolean = false;
    private isWorkDetailsValid: boolean = false;

    constructor(private workflowService: WorkflowService) {
    }
    // #region Personal

    getPersonal(): Personal {
        // Return the Personal data
        var personal: Personal = {
            firstName: this.formData.firstName,
            lastName: this.formData.lastName,
            email: this.formData.email
        };
        return personal;
    }

    setPersonal(data: Personal) {
        // Update the Personal data only when the Personal Form had been validated successfully
        this.isPersonalFormValid = true;
        this.formData.firstName = data.firstName;
        this.formData.lastName = data.lastName;
        this.formData.email = data.email;
        // Validate Personal Step in Workflow
        this.workflowService.validateStep(STEPS.personal);
    }

    // #endRegion Personal

    // region Education Details

    getEducation(): EducationDetails {
        var educationDetails: EducationDetails = {
            startDate: this.formData.startDate,
            endDate: this.formData.endDate,
            institutionName: this.formData.institutionName,
            universityName: this.formData.universityName,
            certificatePath: this.formData.certificatePath
        };

        return educationDetails;
    }

    setEducation(educationDetails: EducationDetails) {
        // Update the work type only when the Work Form had been validated successfully
        this.formData.startDate = educationDetails.startDate;
        this.formData.endDate = educationDetails.endDate;
        this.formData.institutionName = educationDetails.institutionName;
        this.formData.universityName = educationDetails.universityName;
        this.formData.certificatePath = educationDetails.certificatePath;
        // Validate Work Step in Workflow
        this.workflowService.validateStep(STEPS.educaation);
    }


    // End region Education Details

    // End region Work Details
    getWorkDetails(): WorkDetails {
        // Return the Address data
        var workDetails: WorkDetails = {
            workingStartDate: this.formData.workingStartDate,
            workingEndDate: this.formData.workingEndDate,
            isStillWorking: this.formData.isStillWorking,
            companyName: this.formData.companyName,
            releavingLetter: this.formData.releavingLetter,
            experianceLetter: this.formData.experianceLetter,
            companyAddress:this.formData.companyAddress,
            companyCity:this.formData.companyCity,
            stateProvinceRegion:this.formData.stateProvinceRegion, 
            postalcodeZip:this.formData.postalcodeZip,
            companyCountry:this.formData.companyCountry,
            companyphoneNumber:this.formData.companyphoneNumber,
            companyEmailId:this.formData.companyEmailId,
            refNumber:this.formData.refNumber,

        };
        return workDetails;
    }

    setWorkDetails(work: WorkDetails) {
        // Update the Work data only when the Address Form had been validated successfully
        this.formData.workingStartDate = work.workingStartDate;
        this.formData.workingEndDate = work.workingEndDate;
        this.formData.isStillWorking = work.isStillWorking;
        this.formData.companyName = work.companyName;
        this.formData.releavingLetter = work.releavingLetter;
        this.formData.experianceLetter = work.experianceLetter;
        this.formData.companyAddress=work.companyAddress,
            this.formData.companyCity=work.companyCity,
            this.formData.stateProvinceRegion=work.stateProvinceRegion, 
            this.formData.postalcodeZip=work.postalcodeZip,
            this.formData.companyCountry=work.companyCountry,
            this.formData.companyphoneNumber=work.companyphoneNumber,
            this.formData.companyEmailId=work.companyEmailId,
            this.formData.refNumber=work.refNumber

        // Validate Work Step in Workflow
        this.workflowService.validateStep(STEPS.work);
        
    }
    // End region Work Details
    getFormData(): FormData {
        // Return the entire Form Data
        return this.formData;
    }

    resetFormData(): FormData {
        // Reset the workflow
        this.workflowService.resetSteps();
        // Return the form data after all this.* members had been reset
        this.formData.clear();
        this.isPersonalFormValid = this.isWorkFormValid = this.isAddressFormValid = false;
        return this.formData;
    }

    isFormValid() {
        // Return true if all forms had been validated successfully; otherwise, return false
        return this.isPersonalFormValid &&
            this.isWorkFormValid &&
            this.isAddressFormValid;
    }
}