import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { WorkDetails } from './formdata.model';

@Injectable()
export class WorkService{
    
    constructor(private _httpClient:HttpClient){

    }
    getWorkDetails():Observable<WorkDetails[]>
    {
return this._httpClient.get<WorkDetails[]>('http://localhost:3000/api/work')
    }
    saveWorkDetails(workService:WorkService):Observable<string>{
        return this._httpClient.post<string>('http://localhost:3000/api/work',workService);
    }
}

