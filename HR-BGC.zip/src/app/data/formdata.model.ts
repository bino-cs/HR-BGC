export class FormData {
    firstName: string = '';
    lastName: string = '';
    email: string = '';
    work: string = '';
    street: string = '';
    city: string = '';
    state: string = '';
    zip: string = '';
    dob: string = '';
    contactNumber: string = '';
    startDate: string = '';
    endDate: string = '';
    institutionName: string = '';
    universityName: string = '';
    certificatePath: string = '';
    workingStartDate: string = '';
    workingEndDate: string = '';
    isStillWorking:boolean=false;
    companyName: string = '';
    releavingLetter: string = '';
    experianceLetter: string = '';   
    companyAddress:string='';
    companyCity:string='';
    stateProvinceRegion:string=''    
    postalcodeZip:string='';
    companyCountry:string='';
    companyphoneNumber:string='';
    companyEmailId:string=''; 
    refNumber:string='';
    clear() {
        this.firstName = '';
        this.lastName = '';
        this.email = '';
        this.work = '';
        this.street = '';
        this.city = '';
        this.state = '';
        this.zip = '';
        this.dob = '';
        this.contactNumber = '';
    }
}

export class Personal {
    firstName: string = '';
    lastName: string = '';
    email: string = '';
}

export class Address {
        street: string = '';
        city: string = '';
        state: string = '';
        zip: string = '';
}

export class EducationDetails {
    startDate: string = '';
    endDate: string = '';
    institutionName: string = '';
    universityName: string = '';
    certificatePath: string = '';    
    
}

export class WorkDetails{
    companyName: string = '';
    isStillWorking:boolean=false ;
    workingStartDate: string = '';
    workingEndDate: string = '';
    companyAddress:string='';
    companyCity:string='';
    stateProvinceRegion:string=''    
    postalcodeZip:string='';
    companyCountry:string='';
    companyphoneNumber:string='';
    companyEmailId:string='';
    refNumber:string='';
    releavingLetter: string = '';
    experianceLetter: string = '';    
}