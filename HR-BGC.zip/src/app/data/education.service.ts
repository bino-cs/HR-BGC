import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs";
import { EducationDetails } from '../data/formdata.model'

@Injectable()
export class EducationService {

    
    constructor(private _httpClient: HttpClient) { }

    getAllEducation(): Observable<EducationDetails[]> {
        return this._httpClient.get<EducationDetails[]>('http://localhost:3000/api/education');
    }

    saveAllEducation(educationDetails:EducationDetails):Observable<string>{
        return this._httpClient.post<string>('http://localhost:3000/api/education',educationDetails);
    }
}