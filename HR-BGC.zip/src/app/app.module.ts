import { NgModule }           from '@angular/core';
import { BrowserModule }      from '@angular/platform-browser';
import { FormsModule }        from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

/* App root */
import { AppComponent }       from './app.component';
import { NavbarComponent }    from './navbar/navbar.component';

/*Feature component */
import { PersonalComponent }  from './personal/personal.component';
import { EducationComponent }      from './education/education.component';
import { WorkComponent }   from './work/work.component';
import { ResultComponent }    from './result/result.component';
import { SwitchComponent } from './toggle/switch.component';
import { ToggleComponent } from './toggle/toggle.component';

/* Routing module */
import { AppRoutingModule }   from './app-routing.module';

/* Share d services */
import { FormDataService }    from './data/formData.service';
import { WorkflowService }    from './workflow/workflow.service';

@NgModule({
  imports:        [ NgbModule.forRoot() ,
                    BrowserModule,
                    AppRoutingModule,
                    FormsModule
                  ],
  providers:      [{ provide:FormDataService,useClass: FormDataService},
                  { provide: WorkflowService, useClass: WorkflowService }],
  declarations:   [ AppComponent,NavbarComponent,PersonalComponent,EducationComponent,WorkComponent,ResultComponent,ToggleComponent,SwitchComponent],    
  bootstrap:      [AppComponent]
})
export class AppModule { }
